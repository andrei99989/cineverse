import React, { useState } from "react";
import { Search, Sparkles, Wand2 } from "lucide-react";
import { apiGet } from "./api";

export default function UploadMetadataSearch() {
  const [query, setQuery] = useState("avatar");
  const [type, setType] = useState("movie");
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState(null);

  async function search(event) {
    event.preventDefault();
    if (!query.trim()) return;

    setLoading(true);

    try {
      let path = `/search-metadata?q=${encodeURIComponent(query)}`;

      if (type === "anime") {
        path = `/anime?q=${encodeURIComponent(query)}`;
      }

      if (type === "imdb") {
        path = `/imdb?q=${encodeURIComponent(query)}`;
      }

      const data = await apiGet(path);
      setResults(data);
    } catch (error) {
      setResults({ ok: false, error: error.message });
    }

    setLoading(false);
  }

  function fillField(name, value) {
    const element = document.querySelector(`[name="${name}"]`);
    if (element) element.value = value || "";
  }

  async function fillFromTmdb(item) {
    const poster = item.poster_path
      ? `https://image.tmdb.org/t/p/w500${item.poster_path}`
      : "";

    let trailerUrl = "";

    try {
      const videos = await apiGet(`/tmdb-videos?id=${encodeURIComponent(item.id)}`);
      trailerUrl = videos.youtubeUrl || videos.embedUrl || "";
    } catch {
      trailerUrl = "";
    }

    fillField("title", item.title || "");
    fillField("movieTitle", item.title || "");
    fillField("posterUrl", poster);

    if (trailerUrl) {
      fillField("value", trailerUrl);
    }

    fillField(
      "notes",
      JSON.stringify(
        {
          source: "TMDB",
          originalTitle: item.original_title,
          year: item.release_date ? item.release_date.slice(0, 4) : "",
          rating: item.vote_average,
          description: item.overview,
          tmdbId: item.id,
          trailerUrl
        },
        null,
        2
      )
    );

    alert(
      trailerUrl
        ? "Metadata TMDB + trailer completate în Upload."
        : "Metadata TMDB completată. Nu am găsit trailer automat, pune manual URL/iframe."
    );
  }

  function fillFromOmdb(item) {
    fillField("title", item.Title || "");
    fillField("movieTitle", item.Title || "");
    fillField("posterUrl", item.Poster && item.Poster !== "N/A" ? item.Poster : "");
    fillField(
      "notes",
      JSON.stringify(
        {
          source: "OMDb / IMDb",
          year: item.Year,
          imdbID: item.imdbID,
          type: item.Type
        },
        null,
        2
      )
    );

    alert("Metadata OMDb/IMDb completată în Upload. Pentru video, pune manual URL/iframe.");
  }

  function fillFromAnime(item, source) {
    let title = "";
    let poster = "";
    let description = "";
    let year = "";
    let score = "";
    let trailerUrl = "";

    if (source === "jikan") {
      title = item.title || "";
      poster = item.images?.jpg?.image_url || "";
      description = item.synopsis || "";
      year = item.year || "";
      score = item.score || "";
      trailerUrl = item.trailer?.url || item.trailer?.embed_url || "";
    }

    if (source === "anilist") {
      title = item.title?.romaji || item.title?.english || "";
      poster = item.coverImage?.large || "";
      description = item.description || "";
      year = item.seasonYear || "";
      score = item.averageScore || "";
    }

    if (source === "kitsu") {
      title = item.attributes?.canonicalTitle || "";
      poster = item.attributes?.posterImage?.medium || "";
      description = item.attributes?.synopsis || "";
      year = item.attributes?.startDate || "";
      score = item.attributes?.averageRating || "";
    }

    fillField("title", title);
    fillField("movieTitle", title);
    fillField("posterUrl", poster);

    if (trailerUrl) {
      fillField("value", trailerUrl);
    }

    fillField(
      "notes",
      JSON.stringify(
        {
          source,
          category: "Anime",
          year,
          score,
          description,
          trailerUrl
        },
        null,
        2
      )
    );

    alert(
      trailerUrl
        ? "Metadata Anime + trailer completate în Upload."
        : "Metadata Anime completată. Pentru video, pune manual URL/iframe."
    );
  }

  const tmdb = results?.tmdb || [];
  const omdb = results?.omdb || results?.results || [];
  const jikan = results?.jikan || results?.results || [];
  const anilist = results?.anilist || [];
  const kitsu = results?.kitsu || [];

  return (
    <section className="section metadataSearchBox">
      <h2><Sparkles size={24} /> Upload AI Metadata</h2>
      <p>Caută metadata și completează automat formularul Upload. TMDB poate completa și trailer YouTube automat.</p>

      <form className="toolbar" onSubmit={search}>
        <select value={type} onChange={(event) => setType(event.target.value)}>
          <option value="movie">TMDB + OMDb</option>
          <option value="imdb">IMDb / OMDb</option>
          <option value="anime">Anime</option>
        </select>

        <div className="searchBox compact">
          <Search size={20} />
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Ex: Avatar, Naruto, Squid Game..."
          />
        </div>

        <button type="submit">
          {loading ? "Se caută..." : "Caută metadata"}
        </button>
      </form>

      {results?.ok === false && <p className="empty">{results.error}</p>}

      {tmdb.length > 0 && (
        <div className="metadataResults">
          <h3>TMDB</h3>
          <div className="resultGrid">
            {tmdb.slice(0, 8).map((item) => (
              <article className="resultCard" key={`upload-tmdb-${item.id}`}>
                {item.poster_path ? (
                  <img src={`https://image.tmdb.org/t/p/w500${item.poster_path}`} alt={item.title} />
                ) : (
                  <div className="resultNoImage">No image</div>
                )}

                <div className="resultBody">
                  <h3>{item.title}</h3>
                  <p className="resultSubtitle">{item.release_date || "N/A"} · ⭐ {item.vote_average || "-"}</p>
                  <p>{item.overview?.slice(0, 160) || "Fără descriere."}</p>

                  <button type="button" onClick={() => fillFromTmdb(item)}>
                    <Wand2 size={16} />
                    Folosește + trailer
                  </button>
                </div>
              </article>
            ))}
          </div>
        </div>
      )}

      {omdb.length > 0 && type !== "anime" && (
        <div className="metadataResults">
          <h3>OMDb / IMDb</h3>
          <div className="resultGrid">
            {omdb.slice(0, 8).map((item) => (
              <article className="resultCard" key={`upload-omdb-${item.imdbID}`}>
                {item.Poster && item.Poster !== "N/A" ? (
                  <img src={item.Poster} alt={item.Title} />
                ) : (
                  <div className="resultNoImage">No image</div>
                )}

                <div className="resultBody">
                  <h3>{item.Title}</h3>
                  <p className="resultSubtitle">{item.Year} · {item.Type} · {item.imdbID}</p>

                  <button type="button" onClick={() => fillFromOmdb(item)}>
                    <Wand2 size={16} />
                    Folosește în Upload
                  </button>
                </div>
              </article>
            ))}
          </div>
        </div>
      )}

      {type === "anime" && jikan.length > 0 && (
        <div className="metadataResults">
          <h3>Anime / Jikan</h3>
          <div className="resultGrid">
            {jikan.slice(0, 8).map((item) => (
              <article className="resultCard" key={`upload-jikan-${item.mal_id}`}>
                {item.images?.jpg?.image_url ? (
                  <img src={item.images.jpg.image_url} alt={item.title} />
                ) : (
                  <div className="resultNoImage">No image</div>
                )}

                <div className="resultBody">
                  <h3>{item.title}</h3>
                  <p className="resultSubtitle">{item.year || "N/A"} · ⭐ {item.score || "-"}</p>
                  <p>{item.synopsis?.slice(0, 160) || "Fără descriere."}</p>

                  <button type="button" onClick={() => fillFromAnime(item, "jikan")}>
                    <Wand2 size={16} />
                    Folosește în Upload
                  </button>
                </div>
              </article>
            ))}
          </div>
        </div>
      )}

      {type === "anime" && anilist.length > 0 && (
        <div className="metadataResults">
          <h3>AniList</h3>
          <div className="resultGrid">
            {anilist.slice(0, 8).map((item) => (
              <article className="resultCard" key={`upload-anilist-${item.id}`}>
                {item.coverImage?.large ? (
                  <img src={item.coverImage.large} alt={item.title?.romaji} />
                ) : (
                  <div className="resultNoImage">No image</div>
                )}

                <div className="resultBody">
                  <h3>{item.title?.romaji || item.title?.english}</h3>
                  <p className="resultSubtitle">{item.seasonYear || "N/A"} · {item.averageScore || "-"}%</p>

                  <button type="button" onClick={() => fillFromAnime(item, "anilist")}>
                    <Wand2 size={16} />
                    Folosește în Upload
                  </button>
                </div>
              </article>
            ))}
          </div>
        </div>
      )}

      {type === "anime" && kitsu.length > 0 && (
        <div className="metadataResults">
          <h3>Kitsu</h3>
          <div className="resultGrid">
            {kitsu.slice(0, 8).map((item) => (
              <article className="resultCard" key={`upload-kitsu-${item.id}`}>
                {item.attributes?.posterImage?.medium ? (
                  <img src={item.attributes.posterImage.medium} alt={item.attributes?.canonicalTitle} />
                ) : (
                  <div className="resultNoImage">No image</div>
                )}

                <div className="resultBody">
                  <h3>{item.attributes?.canonicalTitle}</h3>
                  <p className="resultSubtitle">{item.attributes?.startDate || "N/A"} · {item.attributes?.averageRating || "-"}</p>

                  <button type="button" onClick={() => fillFromAnime(item, "kitsu")}>
                    <Wand2 size={16} />
                    Folosește în Upload
                  </button>
                </div>
              </article>
            ))}
          </div>
        </div>
      )}
    </section>
  );
}
